package appmain;
import javax.swing.JTextArea;

public class LexicalAnalyzer {

    static String[] rwtab=new String[]{"char","short","int","long","float","double","final",
    									"static","if","else","while","do","for","break","continue",
    									"void"};   //�Ѿ�����Ĺؼ���
    static String storage="";   //�洢Դ�����ַ���
    static StringBuilder token=new StringBuilder("");     //�洢����������ɵ��ַ���

    private int index=0;		//�����ַ����ű�
    private int syn;			//�ֱ���
    private int row=1;

     //������
     void analyzer(){
        token.delete(0, token.length());                //�ÿ�token�������
         //������ȡ�ַ�
         char lastchar = storage.charAt(index);
        if(((lastchar >='a'&& lastchar <='z')||(lastchar >='A'&& lastchar <='Z'))){    //�����ǹؼ��ֻ����Զ���ı�ʶ��
        	index++; 
        	token.append(lastchar);
            while(((lastchar >='0'&& lastchar <='9')||(lastchar >='a'&& lastchar <='z')||(lastchar >='A'&& lastchar <='Z'))&&index<storage.length()){
            	lastchar =storage.charAt(index++);
            	if((lastchar >='0'&& lastchar <='9')||(lastchar >='a'&& lastchar <='z')||(lastchar >='A'&& lastchar <='Z')) {
            		token.append(lastchar);
            	}else {
            		index--;//���һ��û��ʶ�𣬶�index++�����Խ���-1������Ҳһ��
            	}
            }
            syn=20;       //Ĭ��Ϊʶ������ַ���Ϊ�Զ���ı�ʶ�����ֱ���Ϊ20
            String s=token.toString();
            for(int i=0; i<rwtab.length; i++){
                if(s.equals(rwtab[i])){     
                    syn=i+1;
                    break;        //ʶ����ǹؼ���
                }
            }
        }else if((lastchar >='0'&& lastchar <='9')){		//����
        	index++;
        	token.append(lastchar);
            while((lastchar >='0'&& lastchar <='9'|| lastchar =='.')&&index<storage.length()){
                lastchar =storage.charAt(index++);
                if((lastchar >='0'&& lastchar <='9')|| lastchar =='.') {
                	 token.append(lastchar);
                }else {
                	index--;
                }
            }
            syn=30;						//�������ֱ���Ϊ3
        }else {
        	index++;
        	switch(lastchar){
        	case '+':token.append(lastchar);syn=37;break;
            case '-':token.append(lastchar);syn=38;break;
            case '*':token.append(lastchar);syn=39;break;
            case '<':
                token.append(lastchar);
                syn=34;
                if(index<storage.length()) {
                	lastchar =storage.charAt(index);
                    if(lastchar =='='){
                        token.append(lastchar);
                        syn=36;
                        index++;
                    }else if(lastchar =='>'){
                        token.append(lastchar);
                        index++;
                    }
                }
                break;
            case '>':
            	token.append(lastchar);
            	syn=33;
                if(index<storage.length()) {
                	lastchar =storage.charAt(index);
                    if(lastchar =='='){
                        token.append(lastchar);
                        syn=35;
                        index++;
                    }
                }
                break;
            case '=':
                token.append(lastchar);
                syn=31;
                if(index<storage.length()) {
                	lastchar =storage.charAt(index);
                	if(lastchar =='='){
                        syn=34;
                        token.append(lastchar);
                        index++;
                    }
                }
                break;
            case '/':
                token.append(lastchar);
                syn=40;
                if(index<storage.length()) {
                	lastchar =storage.charAt(index);
                    if(lastchar =='/'){
                        while(lastchar !='\n'&&index<storage.length()){
                            lastchar =storage.charAt(index++);  //���Ե��е�//ע�ͣ��Ի���Ϊ�綨
                        }
                        syn=-2;
                    }else if(lastchar =='*'){//���Զ���ע��
                    	char lastchar1 =' ';
                    	do {
							if(++index<storage.length()) {
								lastchar =storage.charAt(index);
							}
							if(index+1<storage.length()){
								lastchar1=storage.charAt(index+1);
							}
						} while ((lastchar !='*'||lastchar1!='/')&&index<storage.length());
                    	index+=2;
                    	syn=-2;
                    }
                }
                break;  
            case ';':token.append(lastchar);syn=49;break;
            case '(':token.append(lastchar);syn=41;break;
            case ')':token.append(lastchar);syn=42;break;
            case ',':token.append(lastchar);syn=47;break;
            case '{':token.append(lastchar);syn=45;break;
            case '}':token.append(lastchar);syn=46;break;
            case '\n':
                syn=-2;
                break;
            case ' ':
            	syn=0;
            	break;
            default:
            	token.append(lastchar);
                syn=-1;
            }
        }
    }
     
    public void execute(String str,JTextArea jta) {
        storage=str;
        //�������
        while(index<storage.length()) {
            analyzer();
            switch(syn){
            case -1:
            	jta.append("��"+row+"�д����޷�ʶ����ַ�\""+token+"\"��\n");
                break;
            case -2:
            	row++;
                break;
            case 0:
            	break;
            default:
            	jta.append("("+syn+","+token+")\n");
            }
        }     
	}
}