package appmain;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;

public class GrammaAnalysis {
    private ArrayList<String> stack = new ArrayList<>(); // ��ǰջ
    private ArrayList<Integer> reader = new ArrayList<>(); // ��������
    private Production[] productions = new Production[42]; // ����ʽ����
    private HashMap<Integer, String> map_i2s; // �ֱ���Map���ֱ���Ϊ��������Ϊֵ
    private HashMap<String, Integer> map_s2i; // �ֱ���Map������Ϊ�����ֱ���Ϊֵ

    private void initMap() {
        map_s2i = new HashMap<>();
        map_s2i.put("char", 1);
        map_s2i.put("short", 2);
        map_s2i.put("int", 3);
        map_s2i.put("long", 4);
        map_s2i.put("float", 5);
        map_s2i.put("double", 6);
        map_s2i.put("final", 7);
        map_s2i.put("", 8);
        map_s2i.put("if", 9);
        map_s2i.put("else", 10);
        map_s2i.put("while", 11);
        map_s2i.put("do", 12);
        map_s2i.put("for", 13);
        map_s2i.put("break", 14);
        map_s2i.put("continue", 15);
        map_s2i.put("void", 16);
        map_s2i.put("id", 20);
        map_s2i.put("num", 30);
        map_s2i.put("=", 31);
        map_s2i.put("==", 32);
        map_s2i.put(">", 33);
        map_s2i.put("<", 34);
        map_s2i.put(">=", 35);
        map_s2i.put("<=", 36);
        map_s2i.put("+", 37);
        map_s2i.put("-", 38);
        map_s2i.put("*", 39);
        map_s2i.put("/", 40);
        map_s2i.put("(", 41);
        map_s2i.put(")", 42);
        map_s2i.put("[", 43);
        map_s2i.put("]", 44);
        map_s2i.put("{", 45);
        map_s2i.put("}", 46);
        map_s2i.put(",", 47);
        map_s2i.put(":", 48);
        map_s2i.put(";", 49);
        map_s2i.put("!=", 50);
        map_s2i.put("$", 60);

        map_i2s = new HashMap<>();
        map_i2s.put(1, "char");
        map_i2s.put(2, "short");
        map_i2s.put(3, "int");
        map_i2s.put(4, "long");
        map_i2s.put(5, "float");
        map_i2s.put(6, "double");
        map_i2s.put(7, "final");
        map_i2s.put(8, "");
        map_i2s.put(9, "if");
        map_i2s.put(10, "else");
        map_i2s.put(11, "while");
        map_i2s.put(12, "do");
        map_i2s.put(13, "for");
        map_i2s.put(14, "break");
        map_i2s.put(15, "continue");
        map_i2s.put(16, "void");
        map_i2s.put(20, "id");
        map_i2s.put(30, "num");
        map_i2s.put(31, "=");
        map_i2s.put(32, "==");
        map_i2s.put(33, ">");
        map_i2s.put(34, "<");
        map_i2s.put(35, ">=");
        map_i2s.put(36, "<=");
        map_i2s.put(37, "+");
        map_i2s.put(38, "-");
        map_i2s.put(39, "*");
        map_i2s.put(40, "/");
        map_i2s.put(41, "(");
        map_i2s.put(42, ")");
        map_i2s.put(43, "[");
        map_i2s.put(44, "]");
        map_i2s.put(45, "{");
        map_i2s.put(46, "}");
        map_i2s.put(47, ",");
        map_i2s.put(48, ":");
        map_i2s.put(49, ";");
        map_i2s.put(50, "!=");
        map_i2s.put(60, "$");
    }

    /**
     * ����ʽ��
     *
     * @author Nonoas
     */
    private static class Production {
        String[] r_str;
        String prod;
        String l_str;

        public Production(String l_str, String[] r_str, String prod) {
            this.l_str = l_str;
            this.r_str = r_str;
            this.prod = prod;
        }
    }

    private void initProductions() {
        productions[0] = new Production("S",
                new String[]{"A", "L", String.valueOf(map_s2i.get(";"))},
                "S --> A L;");
        productions[1] = new Production("S",
                new String[]{String.valueOf(map_s2i.get("id")), "B"},
                "S --> id B");
        productions[2] = new Production("S",
                new String[]{String.valueOf(map_s2i.get("if")), String.valueOf(map_s2i.get("(")), "X", String.valueOf(map_s2i.get(")")), String.valueOf(map_s2i.get("{")), "S", String.valueOf(map_s2i.get("}")), "Q"},
                "S --> if(X){S}Q");
        productions[3] = new Production("S",
                new String[]{String.valueOf(map_s2i.get("while")), String.valueOf(map_s2i.get("(")), "X", String.valueOf(map_s2i.get(")")), String.valueOf(map_s2i.get("{")), "S", String.valueOf(map_s2i.get("}"))},
                "S --> while(X){S}");
        productions[4] = new Production("S",
                new String[]{"��"},
                "S --> ��");
        productions[5] = new Production("B",
                new String[]{String.valueOf(map_s2i.get("(")), "L", String.valueOf(map_s2i.get(")")), String.valueOf(map_s2i.get(";"))},
                "B --> (L);");
        productions[6] = new Production("B",
                new String[]{String.valueOf(map_s2i.get("=")), "E", String.valueOf(map_s2i.get(";"))},
                "B --> =E;");
        productions[7] = new Production("L",
                new String[]{String.valueOf(map_s2i.get("id")), "L'"},
                "L --> id L'");
        productions[8] = new Production("L'",
                new String[]{String.valueOf(map_s2i.get(",")), String.valueOf(map_s2i.get("id")), "L'"},
                "L' --> ,id L'");
        productions[9] = new Production("L'",
                new String[]{"��"},
                "L' --> ��");
        productions[10] = new Production("Q",
                new String[]{String.valueOf(map_s2i.get("else")), String.valueOf(map_s2i.get("{")), "S", String.valueOf(map_s2i.get("}"))},
                "Q --> else{S}");
        productions[11] = new Production("Q",
                new String[]{"��"},
                "Q --> ��");
        productions[12] = new Production("X",
                new String[]{"E", "R", "E"},
                "X --> ERE");
        productions[13] = new Production("E",
                new String[]{String.valueOf(map_s2i.get("+")), "T", "E'"},
                "E --> +TE'");
        productions[14] = new Production("E",
                new String[]{String.valueOf(map_s2i.get("-")), "T", "E'"},
                "E --> -TE'");
        productions[15] = new Production("E",
                new String[]{"T", "E'"},
                "E --> TE'");
        productions[16] = new Production("E'",
                new String[]{"M", "E'"},
                "E' --> ME'");
        productions[17] = new Production("E'",
                new String[]{"��"},
                "E' --> ��");
        productions[18] = new Production("M",
                new String[]{String.valueOf(map_s2i.get("+")), "T"},
                "M --> +T");
        productions[19] = new Production("M",
                new String[]{String.valueOf(map_s2i.get("-")), "T"},
                "M --> -T");
        productions[20] = new Production("T",
                new String[]{"F", "T'"},
                "T --> FT'");
        productions[21] = new Production("T'",
                new String[]{"N", "T'"},
                "T' --> NT'");
        productions[22] = new Production("T'",
                new String[]{"��"},
                "T' --> ��");
        productions[23] = new Production("N",
                new String[]{String.valueOf(map_s2i.get("*")), "F"},
                "N --> *F");
        productions[24] = new Production("N",
                new String[]{String.valueOf(map_s2i.get("/")), "F"},
                "N --> /F");
        productions[25] = new Production("F",
                new String[]{String.valueOf(map_s2i.get("id"))},
                "F --> id");
        productions[26] = new Production("F",
                new String[]{String.valueOf(map_s2i.get("num"))},
                "F --> num");
        productions[27] = new Production("F",
                new String[]{String.valueOf(map_s2i.get("(")), "E", String.valueOf(map_s2i.get(")"))},
                "F --> (E)");
        productions[28] = new Production("R",
                new String[]{String.valueOf(map_s2i.get(">"))},
                "R --> >");
        productions[29] = new Production("R",
                new String[]{String.valueOf(map_s2i.get(">="))},
                "R --> >=");
        productions[30] = new Production("R",
                new String[]{String.valueOf(map_s2i.get("<"))},
                "R --> <");
        productions[31] = new Production("R",
                new String[]{String.valueOf(map_s2i.get("<="))},
                "R --> <=");
        productions[32] = new Production("R",
                new String[]{String.valueOf(map_s2i.get("=="))},
                "R --> ==");
        productions[33] = new Production("R",
                new String[]{String.valueOf(map_s2i.get("!="))},
                "R --> !=");
        productions[34] = new Production("S'",
                new String[]{"S", "S'"},
                "S' --> SS'");
        productions[35] = new Production("S'",
                new String[]{"��"},
                "S' --> ��");
        productions[36] = new Production("A",
                new String[]{String.valueOf(map_s2i.get("char"))},
                "A --> char");
        productions[37] = new Production("A",
                new String[]{String.valueOf(map_s2i.get("short"))},
                "A --> short");
        productions[38] = new Production("A",
                new String[]{String.valueOf(map_s2i.get("int"))},
                "A --> int");
        productions[39] = new Production("A",
                new String[]{String.valueOf(map_s2i.get("long"))},
                "A --> long");
        productions[40] = new Production("A'",
                new String[]{String.valueOf(map_s2i.get("float"))},
                "A --> float");
        productions[41] = new Production("A",
                new String[]{String.valueOf(map_s2i.get("double"))},
                "A --> double");
    }

    public void readToReader(String strLex) {
        String[] lines = strLex.split("\n"); // ��������ÿ�ж�ȡ������
        for (String line : lines) {
            int pos1 = line.indexOf("(") + 1;
            int pos2 = line.indexOf(",");
            reader.add(Integer.valueOf(line.substring(pos1, pos2)));//ȡ�ֱ���
        }
    }

    private boolean match(int stackTop, int readerTop, JTextArea jta) {
        try {
            int stackTopVal = Integer.parseInt(stack.get(stackTop)); // δ�׳��쳣˵�����ս��
            if (stackTopVal == reader.get(0)) {
                stack.remove(stackTop);
                reader.remove(readerTop);
                return true;
            } else {
                return false;
            }
        } catch (NumberFormatException e) {
            // �׳��쳣˵���Ƿ��ս��
            return false;
        }
    }

    private int ll1_table(int stackTop, int readerTop) {
        if ("S".equals(stack.get(stackTop))) {
            if ("char".equals(map_i2s.get(reader.get(readerTop)))) {
                return 0;
            } else if ("short".equals(map_i2s.get(reader.get(readerTop)))) {
                return 0;
            } else if ("int".equals(map_i2s.get(reader.get(readerTop)))) {
                return 0;
            } else if ("long".equals(map_i2s.get(reader.get(readerTop)))) {
                return 0;
            } else if ("float".equals(map_i2s.get(reader.get(readerTop)))) {
                return 0;
            } else if ("double".equals(map_i2s.get(reader.get(readerTop)))) {
                return 0;
            } else if ("id".equals(map_i2s.get(reader.get(readerTop)))) {
                return 1;
            } else if ("if".equals(map_i2s.get(reader.get(readerTop)))) {
                return 2;
            } else if ("while".equals(map_i2s.get(reader.get(readerTop)))) {
                return 3;
            } else if ("}".equals(map_i2s.get(reader.get(readerTop)))) {
                return 4;
            } else if ("$".equals(map_i2s.get(reader.get(readerTop)))) {
                return 4;
            } else {
                return -1;
            }
        } else if ("B".equals(stack.get(stackTop))) {
            if ("(".equals(map_i2s.get(reader.get(readerTop)))) {
                return 5;
            } else if ("=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 6;
            } else {
                return -1;
            }
        } else if ("L".equals(stack.get(stackTop))) {
            if ("id".equals(map_i2s.get(reader.get(readerTop)))) {
                return 7;
            } else {
                return -1;
            }
        } else if ("L'".equals(stack.get(stackTop))) {
            if (";".equals(map_i2s.get(reader.get(readerTop)))) {
                return 9;
            } else if (")".equals(map_i2s.get(reader.get(readerTop)))) {
                return 9;
            } else if ("}".equals(map_i2s.get(reader.get(readerTop)))) {
                return 9;
            } else if ("$".equals(map_i2s.get(reader.get(readerTop)))) {
                return 9;
            } else if (",".equals(map_i2s.get(reader.get(readerTop)))) {
                return 8;
            } else {
                return -1;
            }
        } else if ("Q".equals(stack.get(stackTop))) {
            if ("}".equals(map_i2s.get(reader.get(readerTop)))) {
                return 11;
            } else if ("$".equals(map_i2s.get(reader.get(readerTop)))) {
                return 11;
            } else if ("else".equals(map_i2s.get(reader.get(readerTop)))) {
                return 10;
            } else {
                return -1;
            }
        } else if ("X".equals(stack.get(stackTop))) {
            if ("id".equals(map_i2s.get(reader.get(readerTop)))) {
                return 12;
            } else if ("num".equals(map_i2s.get(reader.get(readerTop)))) {
                return 12;
            } else if ("+".equals(map_i2s.get(reader.get(readerTop)))) {
                return 12;
            } else if ("-".equals(map_i2s.get(reader.get(readerTop)))) {
                return 12;
            } else if ("(".equals(map_i2s.get(reader.get(readerTop)))) {
                return 12;
            } else {
                return -1;
            }
        } else if ("E".equals(stack.get(stackTop))) {
            if ("id".equals(map_i2s.get(reader.get(readerTop)))) {
                return 15;
            } else if ("num".equals(map_i2s.get(reader.get(readerTop)))) {
                return 15;
            } else if ("(".equals(map_i2s.get(reader.get(readerTop)))) {
                return 15;
            } else if ("+".equals(map_i2s.get(reader.get(readerTop)))) {
                return 13;
            } else if ("-".equals(map_i2s.get(reader.get(readerTop)))) {
                return 14;
            } else {
                return -1;
            }
        } else if ("E'".equals(stack.get(stackTop))) {
            if ("+".equals(map_i2s.get(reader.get(readerTop)))) {
                return 16;
            } else if ("-".equals(map_i2s.get(reader.get(readerTop)))) {
                return 16;
            } else if (">".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else if (">=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else if ("<".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else if ("<=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else if ("==".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else if ("!=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else if (";".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else if (")".equals(map_i2s.get(reader.get(readerTop)))) {
                return 17;
            } else {
                return -1;
            }
        } else if ("M".equals(stack.get(stackTop))) {
            if ("+".equals(map_i2s.get(reader.get(readerTop)))) {
                return 18;
            } else if ("-".equals(map_i2s.get(reader.get(readerTop)))) {
                return 19;
            } else {
                return -1;
            }
        } else if ("T".equals(stack.get(stackTop))) {
            if ("id".equals(map_i2s.get(reader.get(readerTop)))) {
                return 20;
            } else if ("num".equals(map_i2s.get(reader.get(readerTop)))) {
                return 20;
            } else if ("(".equals(map_i2s.get(reader.get(readerTop)))) {
                return 20;
            }
        } else if ("T'".equals(stack.get(stackTop))) {
            if ("+".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if ("-".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if ("*".equals(map_i2s.get(reader.get(readerTop)))) {
                return 21;
            } else if ("/".equals(map_i2s.get(reader.get(readerTop)))) {
                return 21;
            } else if (">".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if (">=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if ("<".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if ("<=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if ("==".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if ("!=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if (";".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else if (")".equals(map_i2s.get(reader.get(readerTop)))) {
                return 22;
            } else {
                return -1;
            }
        } else if ("N".equals(stack.get(stackTop))) {
            if ("*".equals(map_i2s.get(reader.get(readerTop)))) {
                return 23;
            } else if ("/".equals(map_i2s.get(reader.get(readerTop)))) {
                return 24;
            } else {
                return -1;
            }
        } else if ("F".equals(stack.get(stackTop))) {
            if ("id".equals(map_i2s.get(reader.get(readerTop)))) {
                return 25;
            } else if ("num".equals(map_i2s.get(reader.get(readerTop)))) {
                return 26;
            } else if ("(".equals(map_i2s.get(reader.get(readerTop)))) {
                return 27;
            } else {
                return -1;
            }
        } else if ("R".equals(stack.get(stackTop))) {
            if (">".equals(map_i2s.get(reader.get(readerTop)))) {
                return 28;
            } else if (">=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 29;
            } else if ("<".equals(map_i2s.get(reader.get(readerTop)))) {
                return 30;
            } else if ("<=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 31;
            } else if ("==".equals(map_i2s.get(reader.get(readerTop)))) {
                return 32;
            } else if ("!=".equals(map_i2s.get(reader.get(readerTop)))) {
                return 33;
            } else {
                return -1;
            }
        } else if ("S'".equals(stack.get(stackTop))) {
            if ("char".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("short".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("int".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("long".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("float".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("double".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("id".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("if".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("while".equals(map_i2s.get(reader.get(readerTop)))) {
                return 34;
            } else if ("$".equals(map_i2s.get(reader.get(readerTop)))) {
                return 35;
            } else {
                return -1;
            }
        } else if ("A".equals(stack.get(stackTop))) {
            if ("char".equals(map_i2s.get(reader.get(readerTop)))) {
                return 36;
            } else if ("short".equals(map_i2s.get(reader.get(readerTop)))) {
                return 37;
            } else if ("int".equals(map_i2s.get(reader.get(readerTop)))) {
                return 38;
            } else if ("long".equals(map_i2s.get(reader.get(readerTop)))) {
                return 39;
            } else if ("float".equals(map_i2s.get(reader.get(readerTop)))) {
                return 40;
            } else if ("double".equals(map_i2s.get(reader.get(readerTop)))) {
                return 41;
            } else {
                return -1;
            }
        } else {
            System.out.println("�﷨����");
        }
        return -1;
    }

    private int stackPush(int stackTop, Production production) {
        int len = production.r_str.length;
        stack.remove(stackTop);
        if (!"��".equals(production.r_str[0])) {
            for (int i = len - 1; i >= 0; i--) {
                stack.add(production.r_str[i]);
            }
            return len - 1;
        }
        return -1;
    }

    public void excuteGra(String strLex, JTextArea jta) {
        int stackTop = 1;
        int readerTop = 0;
        int index = 0; // ��ǰ������
        initMap(); // ��ʼ���ֱ���Map
        initProductions(); // ����ʽ��ʼ��
        stack.add(0, String.valueOf(map_s2i.get("$"))); // ��stack�ײ�����$
        stack.add(stackTop, "S'"); // ��S'ѹ��ջ
        readToReader(strLex);
        reader.add(map_s2i.get("$")); // ��readerĩβ����$
        while (stackTop >= 0) {
            jta.append("��" + ++index + "����");
            jta.append("��ǰջ��");
            StringBuffer sb = new StringBuffer(); // ����StringBuffer��Ϊ�����ڿ���̨�������ʽ����
            for (int i = 0; i <= stackTop; i++) {
                String str;
                try {
                    str = map_i2s.get(Integer.valueOf(stack.get(i)));
                    if (str != null) {
                        sb.append(str).append(" ");
                    }
                } catch (NumberFormatException e) {
                    sb.append(stack.get(i)).append(" ");
                }
            }
            jta.append(sb.toString());
            jta.append("          �������У�");
            sb = new StringBuffer();
            for (Integer integer : reader) {
                sb.append(map_i2s.get(integer)).append(" ");
            }
            jta.append(sb.toString());

            if (match(stackTop, readerTop, jta)) {
                stackTop--;
            } else {
                int i = ll1_table(stackTop, readerTop);
                if (i >= 0) {
                    stackTop += stackPush(stackTop, productions[i]); // ѹջ
                    jta.append("         ��һ�����ò���ʽ��" + productions[i].prod);
                } else {
                    jta.append("\n��ǰ����ʽ����");
                    return;
                }
            }
            jta.append("\n");
        }
        if (stackTop == -1) {
            jta.append("�﷨�����ɹ�\n");
        }
    }
}
