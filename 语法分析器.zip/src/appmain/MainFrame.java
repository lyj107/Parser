package appmain;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class MainFrame extends JFrame {
	
	private static final long serialVersionUID = -6585678562187194388L;
	private JTextArea jta_editor=new JTextArea();
	private JTextArea jta_result=new JTextArea();
	private JLabel jl_sourse=new JLabel("Դ���룺");
	private JLabel jl_result=new JLabel("�ʷ����������");
	private JScrollPane jsp_editor=new JScrollPane(jta_editor);
	private JScrollPane jsp_result=new JScrollPane(jta_result);
	private JPanel jp_north=new JPanel(new GridLayout(1,2,20,0));
	private JPanel jp_center=new JPanel(new GridLayout(1,2,20,10));
	private JPanel jp_south=new JPanel(new FlowLayout(FlowLayout.CENTER,20,20));
	private JButton btn_analyze=new JButton("����");
	private JButton btn_clear=new JButton("���");
	private JTextArea jta_Gra=new JTextArea();
	private JScrollPane jsp_Gra=new JScrollPane(jta_Gra);
	private JPanel jp_Up=new JPanel(new BorderLayout());
	private JPanel jp_Down=new JPanel(new BorderLayout());
	
	public MainFrame() {
		setTitle("�ʷ�������");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(new Dimension(1000,800));
		setMinimumSize(new Dimension(500,400));
		setLocationRelativeTo(null);
		setLayout(new GridLayout(2,1));
		jta_editor.setFont(new Font(null,Font.BOLD,20));
		jta_result.setFont(new Font(null,Font.BOLD,20));
		jta_Gra.setFont(new Font(null,Font.BOLD,15));
		jta_result.setEditable(false);
		jta_Gra.setEditable(false);
		jsp_editor.setBorder(BorderFactory.createEtchedBorder());
		
		jp_north.setBorder(BorderFactory.createEmptyBorder(20,20,0,20));
		jp_north.add(jl_sourse);
		jp_north.add(jl_result);
		
		jp_south.add(btn_clear);
		jp_south.add(btn_analyze);
		
		jp_center.setBorder(BorderFactory.createEmptyBorder(20,20,0,20));
		jp_center.add(jsp_editor);
		jp_center.add(jsp_result);
		jp_Down.setBorder(BorderFactory.createEmptyBorder(20,20,0,20));
		//���Ӱ�ť�¼���ִ�дʷ�����
		btn_analyze.addActionListener((e)->{
			jta_result.setText("");
			jta_Gra.setText("");
			LexicalAnalyzer l=new LexicalAnalyzer();
			l.execute(jta_editor.getText(),jta_result);
			new GrammaAnalysis().excuteGra(jta_result.getText(),jta_Gra);
		});
		btn_clear.addActionListener((e)->{
			jta_editor.setText("");
			jta_result.setText("");
		});
		
		jp_Up.add(jp_north,BorderLayout.NORTH);
		jp_Up.add(jp_center,BorderLayout.CENTER);
		jp_Down.add(jp_south,BorderLayout.SOUTH);
		jp_Down.add(jsp_Gra);
		add(jp_Up);
		add(jp_Down);
		setVisible(true);
	}
	public static void main(String[] args) {
		new MainFrame();
	}
}
